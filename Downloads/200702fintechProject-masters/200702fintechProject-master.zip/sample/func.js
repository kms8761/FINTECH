function newFunc(p1, p2) {
  console.log(p1);
  console.log(p2);
  //----- ,,,,,,.
  //,,,,,,,
  return p1;
}

//#java
//public void method1(){
//}
// public Int methodReturnData(){
// }

function multi(p1, p2) {
  return p1 * p2; // p1, p2 곱연산의 결과를 반환한다.
}

function div(p1, p2) {
  return p1 / p2; // p1, p2 곱연산의 결과를 반환한다.
}

function plus(p1, p2) {
  //...
  //...
  return p1 + p2; // p1, p2 곱연산의 결과를 반환한다.
}

function minus(p1, p2) {
  return p1 - p2; // p1, p2 곱연산의 결과를 반환한다.
}

console.log(multi(3, 2));
console.log(div(3, 2));
console.log(plus(3, 2));
console.log(minus(3, 2));

//#work1 + - * / 기능 작성 및 결과 출력
